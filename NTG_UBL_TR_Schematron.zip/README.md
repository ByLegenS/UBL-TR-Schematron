NTG_UBL_TR_Schematron
=====================
Bu Java yazılımı kodcu.com'un "Schematron-Validation" isimli örneğinden derlenmiştir.
=====================
E-Fatura Schematron Doğrulama Örneği içermektedir.
http://netgenel.net