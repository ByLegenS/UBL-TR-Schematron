package com.ntg;

import se.uglisch.XmlSchemaNsUris;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

@SuppressWarnings("unused")
public class NTGSch {

    public static void main(String[] args) throws Exception {
    	
        try( InputStream UBL = new FileInputStream(args[0]); InputStream fatura = new FileInputStream(args[1])){

            SchemaFactory schemaFactory = SchemaFactory.newInstance(XmlSchemaNsUris.SCHEMATRON_NS_URI);
            Schema schema = schemaFactory.newSchema(new StreamSource(UBL));

            schema.newValidator().validate(new StreamSource(fatura));
        } catch (Exception   e) {
        	System.out.println( e.getMessage());
        }
    }
}
